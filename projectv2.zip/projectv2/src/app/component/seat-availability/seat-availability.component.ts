import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seat-availability',
  templateUrl: './seat-availability.component.html',
  styleUrls: ['./seat-availability.component.scss']
})
export class SeatAvailabilityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
