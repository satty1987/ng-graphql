import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surrender',
  templateUrl: './surrender.component.html',
  styleUrls: ['./surrender.component.scss']
})
export class SurrenderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
