import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { NewsService } from 'src/app/core/services/news.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-new-request',
  templateUrl: './new-reguest.component.html',
  styleUrls: ['./new-reguest.component.scss']
})
export class NewReguestComponent implements OnInit {

  @Input() name: string;
  @Input() requestType: String;
  public request = ['New Request', 'Surrender'];
  public prefferTower = ['Tower 1', 'Tower 2', 'Tower 3'];
  public employeeBands = ['E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8', 'E9', ' E10'];
  regiForm: FormGroup;
  employeeCode: String = '';
  employeeBand: String = '';
  startDate: Date = null;
  endDate: Date = null;
  prefferTowerValue: String = '';

  constructor(private fb: FormBuilder, public apiService: NewsService) {

  }

  ngOnInit() {
    this.regiForm = this.fb.group({
      'employeeCode': [null, Validators.required],
      'employeeBand': [null, Validators.required],
      'startDate': [null, Validators.required],
      'endDate': [null, Validators.required],
      'prefferTowerValue': [null, Validators.required],
    });
  }
  onFormSubmit(form: any) {

    console.log(form);
    if (!_.isEmpty(form)) {
      form.requestType = this.requestType;


      if (this.requestType === 'newRequest') {
        const path = '';
        this.apiService.postHttpRequest(path, form).subscribe((data) => {
          console.log(data);
        });
      }

      if (this.requestType === 'surrenderRequest') {
        const path = '';
        this.apiService.postHttpRequest(path, form).subscribe((data) => {
          console.log(data);
        });
      }
    }
  }

}
