import { Component, OnInit } from '@angular/core';
import { NewsService } from 'src/app/core/services/news.service';
import * as _ from 'lodash';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
dataList : any;
  constructor(public apiService: NewsService) { }

  ngOnInit() {
    const path = '';
    this.apiService.getHttpRequest(path).subscribe((data) =>{
     this.dataList =  data;
    })
  }

}
