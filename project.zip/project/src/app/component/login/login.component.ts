import {OktaAuthService} from '../../core/services/okta-auth.service';
import { interval } from 'rxjs';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FooterComponent } from '../footer/footer.component';

import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(public _oktaAuthService: OktaAuthService,
    public dialog: MatDialog) { }

  public intervallTimer = interval(300);
  public counter;
  public subscription;


  ngOnInit() {
    // this._oktaAuthService.getTmoAccess().subscribe((response) => {
    //   console.log(response);
    // });

  }
loginWithOkta() {
  this._oktaAuthService.loginWithOkta();
}

}
