import { Component, OnInit , Input} from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms';

@Component({
  selector: 'app-new-request',
  templateUrl: './new-reguest.component.html',
  styleUrls: ['./new-reguest.component.scss']
})
export class NewReguestComponent implements OnInit {

 @Input() name: string;
 @Input() requestType: String;
 public request = ['New Request', 'Surrender'];
 public prefferTower  = ['Tower 1', 'Tower 2', 'Tower 3'];
 public employeeBands = ['E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8', 'E9', ' E10'];
 regiForm: FormGroup;
 employeeCode: String = '';
 employeeBand: String = '';
 startDate: Date = null;
 endDate: Date = null;
 prefferTowerValue: String = '';
 





  constructor(private fb: FormBuilder) { 
    
  }

  ngOnInit() {
        this.regiForm = this.fb.group({
          'employeeCode' : [null, Validators.required],
          'employeeBand' : [null, Validators.required],
          'startDate' : [null, Validators.required],
          'endDate' : [null, Validators.required],
          'prefferTowerValue' : [null, Validators.required],
        });
        console.log(this.name);
    console.log(this.requestType);
  }
  onFormSubmit(form: NgForm) {
    console.log(form);
  }

}
